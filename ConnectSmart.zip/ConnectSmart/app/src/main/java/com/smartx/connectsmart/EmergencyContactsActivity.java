package com.smartx.connectsmart;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;

public class EmergencyContactsActivity extends AppCompatActivity {

    EditText etName, etNumber;
    Button btnAdd;
    ListView listView;

    SharedPreferences sp;
    ArrayList<String> contacts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency_contacts);

        etName = findViewById(R.id.etName);
        etNumber = findViewById(R.id.etNumber);
        btnAdd = findViewById(R.id.btnAdd);
        listView = findViewById(R.id.list);

        sp = getSharedPreferences("contacts", MODE_PRIVATE);
        loadContacts();

        btnAdd.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String number = etNumber.getText().toString();

            if (!name.isEmpty() && !number.isEmpty()) {
                sp.edit().putString(number, name).apply();
                etName.setText("");
                etNumber.setText("");
                loadContacts();
            }
        });

        listView.setOnItemLongClickListener((a, b, pos, id) -> {
            String item = contacts.get(pos);
            String number = item.split(" - ")[1];
            sp.edit().remove(number).apply();
            loadContacts();
            return true;
        });
    }

    void loadContacts() {
        contacts.clear();
        Map<String, ?> all = sp.getAll();
        for (String num : all.keySet()) {
            contacts.add(all.get(num) + " - " + num);
        }
        listView.setAdapter(new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, contacts));
    }
}
