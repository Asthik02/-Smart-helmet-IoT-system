package com.smartx.connectsmart;

import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class GroupChatActivity extends AppCompatActivity {

    EditText etMsg;
    Button btnSend;
    ListView list;
    ArrayList<String> msgs = new ArrayList<>();

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_group_chat);

        etMsg = findViewById(R.id.etMsg);
        btnSend = findViewById(R.id.btnSend);
        list = findViewById(R.id.listChat);

        btnSend.setOnClickListener(v -> {
            msgs.add("Me: " + etMsg.getText().toString());
            etMsg.setText("");
            list.setAdapter(new ArrayAdapter<>(
                    this, android.R.layout.simple_list_item_1, msgs));
        });
    }
}
