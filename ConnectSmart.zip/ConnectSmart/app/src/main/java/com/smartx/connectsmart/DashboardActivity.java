package com.smartx.connectsmart;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.osmdroid.api.IMapController;
import org.osmdroid.config.Configuration;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

public class DashboardActivity extends AppCompatActivity {

    // UI
    TextView tvHelmet, tvFall;
    Button btnLogout, btnContacts, btnManualAlert;
    Button btnGroup, btnChat; // ✅ ADDED

    // Map
    MapView map;
    Marker marker;

    Handler handler = new Handler();

    boolean previousFall = false;
    boolean popupActive = false;

    static final int SMS_PERMISSION = 101;
    String SENT = "SMS_SENT";
    String DELIVERED = "SMS_DELIVERED";

    String AUTH = "w6Lam-38gEQPNvPJzCDKyBAPbTrpmDbR";
    String BASE = "https://blynk.cloud/external/api/get?token=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // OSMDroid config
        Configuration.getInstance().load(
                getApplicationContext(),
                PreferenceManager.getDefaultSharedPreferences(this));
        Configuration.getInstance().setUserAgentValue(getPackageName());

        setContentView(R.layout.activity_dashboard);

        // Bind views
        tvHelmet = findViewById(R.id.tvHelmet);
        tvFall = findViewById(R.id.tvFall);

        btnLogout = findViewById(R.id.btnLogout);
        btnContacts = findViewById(R.id.btnContacts);
        btnManualAlert = findViewById(R.id.btnManualAlert);

        btnGroup = findViewById(R.id.btnGroup);   // ✅ ADDED
        btnChat = findViewById(R.id.btnChat);     // ✅ ADDED

        // Map setup
        map = findViewById(R.id.map);
        map.setMultiTouchControls(true);
        marker = new Marker(map);
        map.getOverlays().add(marker);

        // Permissions & services
        checkSmsPermission();
        registerSmsReceivers();
        startAutoRefresh();

        // Button actions
        btnContacts.setOnClickListener(v ->
                startActivity(new Intent(this, EmergencyContactsActivity.class)));

        btnManualAlert.setOnClickListener(v -> sendSMS());

        btnGroup.setOnClickListener(v ->          // ✅ GROUP BUTTON
                startActivity(new Intent(this, GroupActivity.class)));

        btnChat.setOnClickListener(v ->           // ✅ CHAT BUTTON
                startActivity(new Intent(this, GroupChatActivity.class)));

        btnLogout.setOnClickListener(v -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }

    // 🔄 Auto refresh every 5 seconds
    void startAutoRefresh() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchData();
                handler.postDelayed(this, 5000);
            }
        }, 1000);
    }

    // 📡 Fetch data from Blynk Cloud
    void fetchData() {
        new Thread(() -> {
            try {
                String helmet = get("V0");
                String fall = get("V1");
                double lat = Double.parseDouble(get("V2"));
                double lng = Double.parseDouble(get("V3"));

                boolean currentFall = fall.contains("Fall Detected");

                runOnUiThread(() -> {
                    tvHelmet.setText("Helmet : " + helmet);
                    tvFall.setText("Fall : " + fall);

                    GeoPoint p = new GeoPoint(lat, lng);
                    marker.setPosition(p);
                    marker.setTitle("Rider Location");

                    IMapController c = map.getController();
                    c.setZoom(16.0);
                    c.setCenter(p);
                    map.invalidate();

                    // Fall edge detection
                    if (currentFall && !previousFall && !popupActive) {
                        popupActive = true;
                        showPopup();
                    }

                    if (!currentFall) {
                        previousFall = false;
                        popupActive = false;
                    } else {
                        previousFall = true;
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    // 🚨 Popup with 20s cancel
    void showPopup() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("FALL DETECTED")
                .setMessage("SMS will be sent in 20 seconds.\nPress CANCEL to stop.")
                .setCancelable(false)
                .setNegativeButton("CANCEL", (d, w) -> popupActive = false)
                .create();

        dialog.show();

        handler.postDelayed(() -> {
            if (popupActive) {
                sendSMS();
                popupActive = false;
            }
        }, 20000);
    }

    // 📩 Normal SMS alert
    void sendSMS() {
        try {
            SharedPreferences sp = getSharedPreferences("contacts", MODE_PRIVATE);
            Map<String, ?> contacts = sp.getAll();

            if (contacts.isEmpty()) {
                tvFall.setText("No emergency contacts saved");
                return;
            }

            String lat = get("V2");
            String lng = get("V3");

            String msg = "🚨 SMART HELMET ALERT 🚨\n"
                    + "Fall detected.\nLocation:\n"
                    + "https://maps.google.com/?q=" + lat + "," + lng;

            SmsManager sms = SmsManager.getDefault();

            for (String num : contacts.keySet()) {
                PendingIntent sentPI = PendingIntent.getBroadcast(
                        this, 0, new Intent(SENT), PendingIntent.FLAG_IMMUTABLE);
                PendingIntent delPI = PendingIntent.getBroadcast(
                        this, 0, new Intent(DELIVERED), PendingIntent.FLAG_IMMUTABLE);

                sms.sendTextMessage(num, null, msg, sentPI, delPI);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // 🔐 SMS permission
    void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION);
        }
    }

    // 📬 SMS sent & delivered report
    void registerSmsReceivers() {
        registerReceiver(new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                tvFall.setText("SMS Sent");
            }
        }, new IntentFilter(SENT));

        registerReceiver(new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                tvFall.setText("SMS Delivered");
            }
        }, new IntentFilter(DELIVERED));
    }

    // 🌐 HTTP GET
    String get(String pin) throws Exception {
        URL url = new URL(BASE + AUTH + "&" + pin);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        return br.readLine();
    }
}
