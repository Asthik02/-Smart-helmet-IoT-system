package com.smartx.connectsmart;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class GroupActivity extends AppCompatActivity {

    EditText etGroup;
    Button btnCreate, btnJoin, btnDelete;
    TextView tvStatus;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_group);

        etGroup = findViewById(R.id.etGroup);
        btnCreate = findViewById(R.id.btnCreate);
        btnJoin = findViewById(R.id.btnJoin);
        btnDelete = findViewById(R.id.btnDelete);
        tvStatus = findViewById(R.id.tvStatus);

        sp = getSharedPreferences("group", MODE_PRIVATE);

        btnCreate.setOnClickListener(v -> {
            sp.edit().putString("group", etGroup.getText().toString()).apply();
            tvStatus.setText("Group Created");
        });

        btnJoin.setOnClickListener(v ->
                tvStatus.setText("Joined Group: " + etGroup.getText().toString()));

        btnDelete.setOnClickListener(v -> {
            sp.edit().clear().apply();
            tvStatus.setText("Group Deleted");
        });
    }
}
